#!/usr/bin/python3
if __name__ == '__main__':
  import sys
  import os
  sys.path.insert(0, os.path.abspath('config'))
  import configure
  configure_options = [
    '--download-blacs=1',
    '--download-fblaslapack=1',
    '--download-hdf5=1',
    '--download-hypre=1',
    '--download-metis=1',
    '--download-ml=1',
    '--download-mpich=1',
    '--download-mumps=1',
    '--download-parmetis=1',
    '--download-scalapack=1',
    '--download-spooles=1',
    '--download-superlu_dist=1',
    '--prefix=/petsc-installation',
    '--with-cc=clang-12',
    '--with-cxx=clang++-12',
    '--with-debugging=0',
    '--with-pic=1',
    '--with-shared-libraries=1',
    'COPTFLAGS=-O3',
    'CXXOPTFLAGS=-O3',
    'PETSC_ARCH=arch-linux-c-opt',
  ]
  configure.petsc_configure(configure_options)
