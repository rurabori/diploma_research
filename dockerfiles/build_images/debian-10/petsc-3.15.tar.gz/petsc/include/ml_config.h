/* src/ml_config.h.  Generated from ml_config.h.in by configure.  */
/* src/ml_config.h.in.  Generated from configure.ac by autoheader.  */

/* Define the Fortran name mangling to be used for the BLAS */
#define F77_BLAS_MANGLE(name,NAME) name ## _

/* Define to dummy `main' function (if any) required to link to the Fortran
   libraries. */
/* #undef F77_DUMMY_MAIN */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
#define F77_FUNC(name,NAME) name ## _

/* As F77_FUNC, but for C identifiers containing underscores. */
#define F77_FUNC_(name,NAME) name ## _

/* Define if F77 and FC dummy `main' functions are identical. */
/* #undef FC_DUMMY_MAIN_EQ_F77 */

/* Define to 1 if you have the <assert.h> header file. */
/* #undef HAVE_ASSERT_H */

/* Define if you have a BLAS library. */
#define HAVE_BLAS 1

/* define if bool is a built-in type */
#define HAVE_BOOL /**/

/* Define to 1 if you have the <cassert> header file. */
#define HAVE_CASSERT 1

/* Define if the C complier supports __PRETTY_FUNCTION__ */
#define HAVE_CFUNC /**/

/* Define to 1 if you have the <cmath> header file. */
#define HAVE_CMATH 1

/* Define to 1 if you have the <cstdio> header file. */
#define HAVE_CSTDIO 1

/* Define to 1 if you have the <cstdlib> header file. */
#define HAVE_CSTDLIB 1

/* Define if you want to build export makefiles. */
#define HAVE_EXPORT_MAKEFILES /**/

/* Define if you are using gnumake - this will shorten your link lines. */
/* #undef HAVE_GNUMAKE */

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <iomanip> header file. */
#define HAVE_IOMANIP 1

/* Define to 1 if you have the <iomanip.h> header file. */
/* #undef HAVE_IOMANIP_H */

/* Define to 1 if you have the <iostream> header file. */
#define HAVE_IOSTREAM 1

/* Define to 1 if you have the <iostream.h> header file. */
/* #undef HAVE_IOSTREAM_H */

/* Define if you have LAPACK library. */
#define HAVE_LAPACK 1

/* Define if want to build libcheck */
#define HAVE_LIBCHECK /**/

/* Define to 1 if your system has a GNU libc compatible `malloc' function, and
   to 0 otherwise. */
/* #undef HAVE_MALLOC */

/* Define to 1 if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1

/* Define to 1 if you have the <math.h> header file. */
/* #undef HAVE_MATH_H */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_AMESOS */

/* Define if want to build with ml_arpack enabled */
/* #undef HAVE_ML_ARPACK */

/* Define if want to build with ml_aztec2_1 enabled */
/* #undef HAVE_ML_AZTEC2_1 */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_AZTECOO */

/* Define if want to build with ml_benchmarking enabled */
/* #undef HAVE_ML_BENCHMARKING */

/* Define if want to build with ml_complex_maxwell enabled */
/* #undef HAVE_ML_COMPLEX_MAXWELL */

/* Define if want to build with ml_enrich enabled */
/* #undef HAVE_ML_ENRICH */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_EPETRA */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_EPETRAEXT */

/* Define if want to build ml-examples */
/* #undef HAVE_ML_EXAMPLES */

/* Define if want to build with ml_flops enabled */
/* #undef HAVE_ML_FLOPS */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_GALERI */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_IFPACK */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_ISORROPIA */

/* Define if want to build ml-matlab */
/* #undef HAVE_ML_MATLAB */

/* Define if want to build with ml_memory_checking enabled */
/* #undef HAVE_ML_MEMORY_CHECK */

/* Define if want to build with ml_metis enabled */
/* #undef HAVE_ML_METIS */

/* Define if want to build with ml_newtpe enabled */
#define HAVE_ML_NEW_T_PE 1

/* Define if want to build with ml_nox enabled */
/* #undef HAVE_ML_NOX */

/* Define if want to build with ml_parasails enabled */
/* #undef HAVE_ML_PARASAILS */

/* Define if want to build with ml_parmetis2x enabled */
/* #undef HAVE_ML_PARMETIS_2x */

/* Define if want to build with ml_parmetis3x enabled */
/* #undef HAVE_ML_PARMETIS_3x */

/* Define if want to build with ml_parpack enabled */
/* #undef HAVE_ML_PARPACK */

/* Define if want to build with ml_superlu enabled */
/* #undef HAVE_ML_SUPERLU */

/* Define if want to build with ml_superlu2 enabled */
/* #undef HAVE_ML_SUPERLU2_0 */

/* Define if want to build with ml_superlu_dist enabled */
/* #undef HAVE_ML_SUPERLU_DIST */

/* Define if want to build ml-tests */
/* #undef HAVE_ML_TESTS */

/* Define if want to build with ml enabled */
/* #undef HAVE_ML_TEUCHOS */

/* Define if want to build with ml_timing enabled */
/* #undef HAVE_ML_TIMING */

/* Define if want to build with ml_zoltan enabled */
/* #undef HAVE_ML_ZOLTAN */

/* Define if want to build with ml_zoltan3 enabled */
/* #undef HAVE_ML_ZOLTAN_THREE */

/* define if we want to use MPI */
#define HAVE_MPI /**/

/* define if the compiler supports the mutable keyword */
#define HAVE_MUTABLE /**/

/* define if the compiler implements namespaces */
#define HAVE_NAMESPACES /**/

/* define if the compiler accepts the new for scoping rules */
#define HAVE_NEW_FOR_SCOPING /**/

/* Define if want to build with petsc enabled */
/* #undef HAVE_PETSC */

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
/* #undef HAVE_STDIO_H */

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* define if std::sprintf is supported */
#define HAVE_STD_SPRINTF /**/

/* define if the compiler supports Standard Template Library */
#define HAVE_STL /**/

/* Define to 1 if you have the <string> header file. */
#define HAVE_STRING 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define if want to build tests */
/* #undef HAVE_TESTS */

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Support for 64-bit integers */
#define ML_BIG_INT int

/* mallinfo with ML */
#define ML_MALLINFO /**/

/* Support for multiple right hand sides. */
/* #undef ML_MULTIPLE_RHS_BLOCK_FACTOR */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "jhu@sandia.gov"

/* Define to the full name of this package. */
#define PACKAGE_NAME "ml"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "ml 6.2"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "ml"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "6.2"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
/* #undef inline */
#endif

/* Define to rpl_malloc if the replacement function should be used. */
/* #undef malloc */
