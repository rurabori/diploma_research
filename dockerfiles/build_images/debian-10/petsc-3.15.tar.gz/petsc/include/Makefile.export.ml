###########################################################################
# These are the include path and the libraries needed to compile the ML
# library, and to link the ML library with another package of an
# application.
###########################################################################

# Optional ML dependencies 
#include /petsc-installation/include/Makefile.export.galeri
#include /petsc-installation/include/Makefile.export.epetra 
#include /petsc-installation/include/Makefile.export.amesos
#include /petsc-installation/include/Makefile.export.ifpack
#include /petsc-installation/include/Makefile.export.teuchos
#include /petsc-installation/include/Makefile.export.aztecoo
#include /petsc-installation/include/Makefile.export.epetraext
#include /code/arch-linux-c-opt/externalpackages/petsc-pkg-ml-e5040d11aa07/../isorropia/Makefile.export.isorropia

# These are the needed includes to build the library
_ML_BUILD_LIB_INCLUDES = \
	    -I/petsc-installation/include \
	    -I/petsc-installation/include \
            -I/petsc-installation/include/Comm \
	    -I/petsc-installation/include/Operator \
	    -I/petsc-installation/include/Smoother \
	    -I/petsc-installation/include/Coarsen \
	    -I/petsc-installation/include/Krylov \
	    -I/petsc-installation/include/Main \
	    -I/petsc-installation/include/FEGrid \
	    -I/petsc-installation/include/Utils \
	    -I/petsc-installation/include/MLAPI \
	    -I/petsc-installation/include/MatrixFree \
	    -I/petsc-installation/include/Include \
	    $(ISORROPIA_INCLUDES) \
	    $(GALERI_INCLUDES) \
	    $(EPETRA_INCLUDES) \
	    $(AMESOS_INCLUDES) \
	    $(IFPACK_INCLUDES) \
	    $(TEUCHOS_INCLUDES) \
	    $(AZTECOO_INCLUDES) \
	    $(EPETRAEXT_INCLUDES)

# These are the needed includes to build the examples
_ML_INCLUDES = \
	    -I/petsc-installation/include \
	    -I/petsc-installation/include \
            -I/petsc-installation/include/Comm \
	    -I/petsc-installation/include/Operator \
	    -I/petsc-installation/include/Smoother \
	    -I/petsc-installation/include/Coarsen \
	    -I/petsc-installation/include/Krylov \
	    -I/petsc-installation/include/Main \
	    -I/petsc-installation/include/FEGrid \
	    -I/petsc-installation/include/Utils \
	    -I/petsc-installation/include/MLAPI \
	    -I/petsc-installation/include/MatrixFree \
	    -I/petsc-installation/include/RefMaxwell \
	    -I/petsc-installation/include/Include \
	    $(ISORROPIA_INCLUDES) \
	    $(GALERI_INCLUDES) \
	    $(EPETRA_INCLUDES) \
	    $(AMESOS_INCLUDES) \
	    $(IFPACK_INCLUDES) \
	    $(TEUCHOS_INCLUDES) \
	    $(AZTECOO_INCLUDES) \
	    $(EPETRAEXT_INCLUDES)

_ML_LIBS =  -L/petsc-installation/lib -lml $(GALERI_LIBS) $(ISORROPIA_LIBS) $(EPETRA_LIBS) $(AMESOS_LIBS) $(IFPACK_LIBS) $(TEUCHOS_LIBS) $(AZTECOO_LIBS) $(EPETRAEXT_LIBS)  -Wl,-rpath,/petsc-installation/lib -L/petsc-installation/lib -lflapack -Wl,-rpath,/petsc-installation/lib -L/petsc-installation/lib -lfblas -lm -lstdc++ -ldl -Wl,-rpath,/petsc-installation/lib -L/petsc-installation/lib -lmpifort -lmpi -lgfortran -lm -Wl,-rpath,/usr/lib/gcc/x86_64-linux-gnu/8 -L/usr/lib/gcc/x86_64-linux-gnu/8 -Wl,-rpath,/petsc-installation/lib -lgfortran -lm -lgcc_s -lquadmath   -L/petsc-installation/lib -L/usr/lib/gcc/x86_64-linux-gnu/8 -L/usr/lib/gcc/x86_64-linux-gnu/8/../../../x86_64-linux-gnu -L/usr/lib/gcc/x86_64-linux-gnu/8/../../../../lib -L/lib/x86_64-linux-gnu -L/lib/../lib -L/usr/lib/x86_64-linux-gnu -L/usr/lib/../lib -L/usr/lib/gcc/x86_64-linux-gnu/8/../../.. -lmpifort -lmpi -lgfortran -lm -lquadmath 

#ML_BUILD_LIB_INCLUDES  = $(shell perl /petsc-installation/include/strip_dup_incl_paths.pl $(_ML_BUILD_LIB_INCLUDES))
#ML_INCLUDES  = $(shell perl /petsc-installation/include/strip_dup_incl_paths.pl $(_ML_INCLUDES))
#ML_LIBS      = $(shell perl /petsc-installation/include/strip_dup_libs.pl $(_ML_LIBS))
ML_BUILD_LIB_INCLUDES = $(_ML_BUILD_LIB_INCLUDES)
ML_INCLUDES = $(_ML_INCLUDES)
ML_LIBS     = $(_ML_LIBS)

###########################################################################
# These variables define the include path and libraries that can be used in
# ML's examples and tests, but that are not required to compile or link
# ML itself.
###########################################################################

#Currently no packages are listed in this area.  Galeri is now used in
# ml/src.

##include /petsc-installation/include/Makefile.export.galeri

_ML_EXTRA_INCLUDES =

_ML_EXTRA_LIBS =

#ML_EXTRA_INCLUDES  = $(shell perl /petsc-installation/include/strip_dup_incl_paths.pl $(_ML_EXTRA_INCLUDES))
#ML_EXTRA_LIBS      = $(shell perl /petsc-installation/include/strip_dup_libs.pl $(_ML_EXTRA_LIBS))
ML_EXTRA_INCLUDES = $(_ML_EXTRA_INCLUDES)
ML_EXTRA_LIBS     = $(_ML_EXTRA_LIBS)

#ML_LINK = $(CXX) $(AM_CFLAGS) $(CFLAGS) $(AM_LDFLAGS) $(LDFLAGS) -o $@
ML_LINK = $(CXX) $(AM_LDFLAGS) $(LDFLAGS) -o $@

# Macro that can be added to a user's Makefile as a dependency to ensure
# relinking if the ML library changes.
ML_LIB_DEP = /code/arch-linux-c-opt/externalpackages/petsc-pkg-ml-e5040d11aa07/src/libml.a
