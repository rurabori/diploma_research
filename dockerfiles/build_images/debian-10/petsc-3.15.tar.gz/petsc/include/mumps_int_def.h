#if ! defined(MUMPS_INT_H)
#   define MUMPS_INT_H
#   define MUMPS_INTSIZE32
#endif
