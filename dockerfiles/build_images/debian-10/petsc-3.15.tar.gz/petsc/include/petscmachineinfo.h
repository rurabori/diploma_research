static const char *petscmachineinfo = "\n"
"-----------------------------------------\n"
"Libraries compiled on 2021-09-05 18:21:15 on 52875f1cc3b2 \n"
"Machine characteristics: Linux-5.10.43.3-microsoft-standard-WSL2-x86_64-with-debian-10.10\n"
"Using PETSc directory: /petsc-installation\n"
"Using PETSc arch: \n"
"-----------------------------------------\n";
static const char *petsccompilerinfo = "\n"
"Using C compiler: /petsc-installation/bin/mpicc  -Wall -Wwrite-strings -Wno-strict-aliasing -Wno-unknown-pragmas -fstack-protector -Qunused-arguments -fvisibility=hidden -O3   \n"
"Using Fortran compiler: /petsc-installation/bin/mpif90  -Wall -ffree-line-length-0 -Wno-unused-dummy-argument -g -O    \n"
"-----------------------------------------\n";
static const char *petsccompilerflagsinfo = "\n"
"Using include paths: -I/petsc-installation/include\n"
"-----------------------------------------\n";
static const char *petsclinkerinfo = "\n"
"Using C linker: /petsc-installation/bin/mpicc\n"
"Using Fortran linker: /petsc-installation/bin/mpif90\n"
"Using libraries: -Wl,-rpath,/petsc-installation/lib -L/petsc-installation/lib -lpetsc -Wl,-rpath,/petsc-installation/lib -L/petsc-installation/lib -Wl,-rpath,/usr/lib/gcc/x86_64-linux-gnu/8 -L/usr/lib/gcc/x86_64-linux-gnu/8 -lHYPRE -lcmumps -ldmumps -lsmumps -lzmumps -lmumps_common -lpord -lpthread -lscalapack -lsuperlu_dist -lml -lflapack -lfblas -lpthread -lhdf5hl_fortran -lhdf5_fortran -lhdf5_hl -lhdf5 -lparmetis -lmetis -lm -lstdc++ -ldl -lmpifort -lmpi -lgfortran -lm -lgfortran -lm -lgcc_s -lquadmath -lstdc++ -ldl\n"
"-----------------------------------------\n";
